import { useEffect, useMemo, useRef, useState } from "react";
import JSZip from "jszip";

type ProjectFile = {
  path: string;
  content: string;
  lang: "kotlin" | "xml" | "gradle" | "properties" | "md" | "yml" | "gitignore";
};

const ANDROID_FILES: ProjectFile[] = [
  {
    path: "app/build.gradle.kts",
    lang: "gradle",
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.panelfinder.ir"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.panelfinder.ir"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
}`,
  },
  {
    path: "app/src/main/AndroidManifest.xml",
    lang: "xml",
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <!-- Consumer IR Blaster access -->
    <uses-permission android:name="android.permission.TRANSMIT_IR" />
    <uses-feature
        android:name="android.hardware.consumerir"
        android:required="true" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.PanelFinderIR">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:screenOrientation="portrait">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>`,
  },
  {
    path: "app/src/main/java/com/panelfinder/ir/MainActivity.kt",
    lang: "kotlin",
    content: `package com.panelfinder.ir

import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.panelfinder.ir.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var irManager: ConsumerIrManager

    private var isScanning = false
    private var currentAddress = 0

    // Standard Chinese MP3/BT panel default POWER command
    private val powerCommandByte = 0x45

    // 1200ms steady interval between bursts
    private val scanIntervalMs = 1200L

    private val scanHandler = Handler(Looper.getMainLooper())

    private val scanRunnable = object : Runnable {
        override fun run() {
            if (!isScanning) return

            transmitAddress(currentAddress)

            currentAddress++
            if (currentAddress > 255) {
                // Wrap around - keep scanning
                currentAddress = 0
            }

            // Queue next shot
            scanHandler.postDelayed(this, scanIntervalMs)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // --- Consumer IR Init ---
        irManager = getSystemService(Context.CONSUMER_IR_SERVICE) as ConsumerIrManager

        if (!irManager.hasIrEmitter()) {
            binding.tvStatus.text = "Error: Hardware Missing IR Blaster"
            binding.btnBruteForce.isEnabled = false
            binding.btnBruteForce.alpha = 0.45f
            Toast.makeText(this, "No Consumer IR emitter found on this device.", Toast.LENGTH_LONG).show()
            return
        }

        // Log available carrier frequencies
        val freqRanges = irManager.carrierFrequencies
        val supported = freqRanges.any { it.minFrequency <= 38000 && it.maxFrequency >= 38000 }
        binding.tvCarrierInfo.text = if (supported) {
            "Carrier: 38 kHz • NEC • Ready"
        } else {
            "Warning: 38kHz not in reported ranges"
        }

        binding.btnBruteForce.setOnClickListener {
            toggleBruteForce()
        }

        updateStatusIdle()
    }

    private fun toggleBruteForce() {
        if (isScanning) {
            stopScan()
        } else {
            startScan()
        }
    }

    private fun startScan() {
        isScanning = true
        currentAddress = 0

        binding.btnBruteForce.text = "STOP\\nSCAN"
        binding.btnBruteForce.setBackgroundResource(R.drawable.btn_ir_circle_stop)

        binding.tvStatus.text = "Scanning..."
        Toast.makeText(this, "IR Scan started", Toast.LENGTH_SHORT).show()

        // Fire immediately, loop handles the rest
        scanHandler.post(scanRunnable)
    }

    private fun stopScan() {
        isScanning = false

        // Kill-switch: strip all callbacks from handler pipeline
        scanHandler.removeCallbacksAndMessages(null)

        binding.btnBruteForce.text = "START\\nSCAN"
        binding.btnBruteForce.setBackgroundResource(R.drawable.btn_ir_circle)

        updateStatusIdle()
        Toast.makeText(this, "Scan stopped", Toast.LENGTH_SHORT).show()
    }

    private fun transmitAddress(address: Int) {
        val pattern = generateNecPattern(address, powerCommandByte)

        try {
            irManager.transmit(38000, pattern)
            binding.tvStatus.text = "Scanning: Addr 0x%02X  •  %d / 255".format(address, address)
            binding.tvCurrentCode.text = "0x%02X  |  CMD 0x%02X".format(address, powerCommandByte)
        } catch (e: Exception) {
            binding.tvStatus.text = "TX Error: \${e.message}"
        }
    }

    /**
     * NEC Infrared Carrier Protocol Pattern Generator
     *
     * Base Frequency: 38000 Hz (38 kHz)
     * AGC Leader: 9000us HIGH, 4500us LOW
     * Bit structure: [Address] + [~Address] + [Command] + [~Command]
     * Bit '1': 560us Burst + 1690us Space
     * Bit '0': 560us Burst + 560us Space
     * Stop: 560us Burst
     */
    private fun generateNecPattern(address: Int, command: Int): IntArray {
        val pattern = mutableListOf<Int>()

        // AGC Leader Pulse
        pattern.add(9000)
        pattern.add(4500)

        // 32-bit NEC frame: Address, ~Address, Command, ~Command
        val frameBytes = intArrayOf(
            address and 0xFF,
            address.inv() and 0xFF,
            command and 0xFF,
            command.inv() and 0xFF
        )

        // Encode LSB first per byte
        for (byte in frameBytes) {
            for (bitIndex in 0 until 8) {
                val bit = (byte shr bitIndex) and 1
                pattern.add(560) // Burst mark
                if (bit == 1) {
                    pattern.add(1690) // Logic 1 space
                } else {
                    pattern.add(560)  // Logic 0 space
                }
            }
        }

        // Terminal stop mark
        pattern.add(560)

        return pattern.toIntArray()
    }

    override fun onPause() {
        super.onPause()
        // Hard stop if app loses focus
        if (isScanning) {
            stopScan()
        }
    }

    override fun onDestroy() {
        scanHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun updateStatusIdle() {
        binding.tvStatus.text = "Ready to Scan"
        binding.tvCurrentCode.text = "IDLE"
    }
}`,
  },
  {
    path: "app/src/main/res/layout/activity_main.xml",
    lang: "xml",
    content: `<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#13131A"
    tools:context=".MainActivity">

    <!-- Top bar -->
    <TextView
        android:id="@+id/tv_app_title"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:layout_marginStart="24dp"
        android:layout_marginTop="44dp"
        android:layout_marginEnd="24dp"
        android:fontFamily="sans-serif-medium"
        android:text="PANEL FINDER IR"
        android:textColor="#FF7844"
        android:textSize="12sp"
        android:letterSpacing="0.18"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toTopOf="parent" />

    <TextView
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:layout_marginTop="6dp"
        android:text="MP3 / Bluetooth Panel"
        android:textColor="#727281"
        android:textSize="13sp"
        app:layout_constraintEnd_toEndOf="@id/tv_app_title"
        app:layout_constraintStart_toStartOf="@id/tv_app_title"
        app:layout_constraintTop_toBottomOf="@id/tv_app_title" />

    <!-- Status TextView (REQUIRED) -->
    <TextView
        android:id="@+id/tv_status"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:layout_marginHorizontal="28dp"
        android:layout_marginTop="54dp"
        android:gravity="center"
        android:text="Ready to Scan"
        android:textColor="#FFFFFF"
        android:textSize="18sp"
        android:fontFamily="sans-serif-medium"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toBottomOf="@id/tv_app_title" />

    <!-- Live code readout -->
    <TextView
        android:id="@+id/tv_current_code"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="10dp"
        android:background="@drawable/chip_bg"
        android:paddingHorizontal="18dp"
        android:paddingVertical="8dp"
        android:text="IDLE"
        android:textColor="#FED9C9"
        android:fontFamily="monospace"
        android:textSize="13sp"
        android:letterSpacing="0.04"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toBottomOf="@id/tv_status" />

    <!-- IR Button (REQUIRED: btn_brute_force) -->
    <Button
        android:id="@+id/btn_brute_force"
        android:layout_width="196dp"
        android:layout_height="196dp"
        android:layout_marginTop="48dp"
        android:background="@drawable/btn_ir_circle"
        android:fontFamily="sans-serif-black"
        android:letterSpacing="0.06"
        android:lineSpacingExtra="3sp"
        android:text="START\nSCAN"
        android:textColor="#FFFFFF"
        android:textSize="21sp"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toBottomOf="@id/tv_current_code" />

    <!-- Carrier info -->
    <TextView
        android:id="@+id/tv_carrier_info"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="18dp"
        android:text="Carrier: 38 kHz • NEC"
        android:textColor="#5B5B6A"
        android:textSize="12sp"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toBottomOf="@id/btn_brute_force" />

    <!-- Instructional Text Block -->
    <LinearLayout
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:layout_marginHorizontal="28dp"
        android:layout_marginTop="44dp"
        android:orientation="vertical"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toBottomOf="@id/tv_carrier_info">

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="HOW TO USE"
            android:textColor="#FF7844"
            android:textSize="11sp"
            android:fontFamily="sans-serif-medium"
            android:letterSpacing="0.14" />

        <TextView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="12dp"
            android:lineSpacingExtra="4dp"
            android:text="1. Point the top IR LED of your phone directly at the MP3/Bluetooth audio panel, within 1–3 meters.\n\n2. Tap START SCAN. The app will brute-force NEC Power (0x45) across all 256 device addresses, one every 1.2s.\n\n3. Watch the panel. When it responds — powers on/off, switches input, or beeps — tap STOP SCAN immediately.\n\n4. Your panel’s IR address is shown above. Use it in your own remotes or automation."
            android:textColor="#A5A5B6"
            android:textSize="14sp" />

        <TextView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="18dp"
            android:lineSpacingExtra="3dp"
            android:text="Protocol: NEC 38 kHz • Cmd fixed at 0x45\nAddress sweep: 0x00 → 0xFF • Interval: 1200 ms"
            android:textColor="#656576"
            android:textSize="12sp"
            android:fontFamily="monospace" />

    </LinearLayout>

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginBottom="20dp"
        android:text="Requires a phone with Consumer IR blaster"
        android:textColor="#3E3E4A"
        android:textSize="11sp"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent" />

</androidx.constraintlayout.widget.ConstraintLayout>`,
  },
  {
    path: "app/src/main/res/values/strings.xml",
    lang: "xml",
    content: `<resources>
    <string name="app_name">PanelFinder IR</string>
</resources>`,
  },
  {
    path: "app/src/main/res/values/colors.xml",
    lang: "xml",
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="black">#13131A</color>
    <color name="ir_red">#E53935</color>
    <color name="ir_red_dark">#B71C1C</color>
    <color name="ir_stop_green">#2E7D32</color>
    <color name="ir_amber">#FF7844</color>
    <color name="white">#FFFFFF</color>
</resources>`,
  },
  {
    path: "app/src/main/res/values/themes.xml",
    lang: "xml",
    content: `<resources xmlns:tools="http://schemas.android.com/tools">
    <style name="Theme.PanelFinderIR" parent="Theme.MaterialComponents.DayNight.NoActionBar">
        <item name="android:statusBarColor">#13131A</item>
        <item name="android:navigationBarColor">#13131A</item>
        <item name="android:windowLightStatusBar">false</item>
        <item name="colorPrimary">@color/ir_amber</item>
    </style>
</resources>`,
  },
  {
    path: "app/src/main/res/drawable/btn_ir_circle.xml",
    lang: "xml",
    content: `<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <!-- Outer glow -->
    <item>
        <shape android:shape="oval">
            <solid android:color="#26E53935" />
        </shape>
    </item>
    <!-- Main button -->
    <item
        android:left="14dp"
        android:top="14dp"
        android:right="14dp"
        android:bottom="14dp">
        <shape android:shape="oval">
            <solid android:color="#E53935" />
            <stroke android:width="2dp" android:color="#FF6F60" />
        </shape>
    </item>
</layer-list>`,
  },
  {
    path: "app/src/main/res/drawable/btn_ir_circle_stop.xml",
    lang: "xml",
    content: `<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item>
        <shape android:shape="oval">
            <solid android:color="#2532C25A" />
        </shape>
    </item>
    <item
        android:left="14dp"
        android:top="14dp"
        android:right="14dp"
        android:bottom="14dp">
        <shape android:shape="oval">
            <solid android:color="#2E7D32" />
            <stroke android:width="2dp" android:color="#66BB6A" />
        </shape>
    </item>
</layer-list>`,
  },
  {
    path: "app/src/main/res/drawable/chip_bg.xml",
    lang: "xml",
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#24242F"/>
    <corners android:radius="999dp"/>
    <stroke android:width="1dp" android:color="#343444"/>
</shape>`,
  },
  {
    path: "build.gradle.kts",
    lang: "gradle",
    content: `// Top-level build file
plugins {
    id("com.android.application") version "8.2.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
}`,
  },
  {
    path: "settings.gradle.kts",
    lang: "gradle",
    content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "PanelFinder IR"
include(":app")`,
  },
  {
    path: "gradle.properties",
    lang: "properties",
    content: `# Project-wide Gradle settings.
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
kotlin.code.style=official
android.nonFinalResIds=false`,
  },
  {
    path: "app/proguard-rules.pro",
    lang: "properties",
    content: `# Keep
-keep class com.panelfinder.ir.** { *; }`,
  },
  {
    path: ".gitignore",
    lang: "gitignore",
    content: `*.iml
.gradle
/local.properties
/.idea/caches
/.idea/libraries
/.idea/modules.xml
/.idea/workspace.xml
/.idea/navEditor.xml
/.idea/assetWizardSettings.xml
.DS_Store
/build
/captures
.externalNativeBuild
.cxx
local.properties
*.apk
*.aab`,
  },
  {
    path: "README.md",
    lang: "md",
    content: `# PanelFinder IR – Chinese MP3 / Bluetooth Audio Panel IR Cracker

Native Android (Kotlin) IR blaster tool for identifying the correct NEC IR address on generic Chinese MP3 / Bluetooth amplifier panels.

These cheap JQ / XY / 747D / 5V Bluetooth MP3 decoder boards all use NEC protocol, but come with random device addresses from the factory (usually 0x00, 0xBF, 0x7F, 0xFF ...). This app brute-forces all 256 possibilities.

### Hardware requirement
A phone with a built-in Consumer IR Blaster.
Tested: Xiaomi / Redmi / Poco, Huawei, Honor, some LG.

### What it does
- Transmits NEC Power command 0x45
- Sweeps device address 0x00 → 0xFF
- 1200 ms interval, steady
- Tap STOP as soon as your panel reacts
- Your working address is shown live

### NEC Timing used
- Carrier: 38,000 Hz
- Leader: 9000 µs / 4500 µs
- Bit 1: 560 µs + 1690 µs
- Bit 0: 560 µs + 560 µs
- Frame: ADDR + ~ADDR + CMD + ~CMD
- Stop burst: 560 µs

### Build
Open in Android Studio Hedgehog or newer.
\`./gradlew assembleDebug\`

Or push to GitHub – the included GitHub Action (\`.github/workflows/android.yml\`) builds a debug APK automatically.

### Permissions
\`\`\`xml
<uses-permission android:name="android.permission.TRANSMIT_IR" />
<uses-feature android:name="android.hardware.consumerir" android:required="true" />
\`\`\`

Min SDK 21, Target SDK 34

MIT License.
`,
  },
  {
    path: ".github/workflows/android.yml",
    lang: "yml",
    content: `name: Android CI - Build APK

on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4

    - name: set up JDK 17
      uses: actions/setup-java@v4
      with:
        java-version: '17'
        distribution: 'temurin'
        cache: gradle

    - name: Grant execute permission for gradlew
      run: chmod +x gradlew

    - name: Build Debug APK
      run: ./gradlew assembleDebug

    - name: Upload APK
      uses: actions/upload-artifact@v4
      with:
        name: PanelFinder-IR-debug
        path: app/build/outputs/apk/debug/app-debug.apk
`,
  },
];

const SUPPORT_FILES: { path: string; content: string }[] = [
  {
    path: "gradlew",
    content: `#!/usr/bin/env sh
echo "Use ./gradlew in your local checkout. This placeholder is for GitHub Actions."`,
  },
  {
    path: "gradle/wrapper/gradle-wrapper.properties",
    content: `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.2-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists`,
  },
  { path: "app/src/main/res/mipmap-xxxhdpi/ic_launcher.xml", content: `<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108"><path android:fillColor="#E53935" android:pathData="M0,0h108v108h-108z"/><path android:fillColor="#fff" android:pathData="M54,34 l12,16 l-12,16 l-12,-16z"/></vector>` },
];

function App() {
  const [activeFile, setActiveFile] = useState<ProjectFile>(ANDROID_FILES[2]);
  const [copyMsg, setCopyMsg] = useState<string>("");
  const [scanPreview, setScanPreview] = useState(false);
  const [scanAddr, setScanAddr] = useState(0);
  const scanTimer = useRef<number | null>(null);

  useEffect(() => {
    if (!scanPreview) return;
    scanTimer.current = window.setInterval(() => {
      setScanAddr(a => (a + 1) % 256);
    }, 320);
    return () => { if (scanTimer.current) window.clearInterval(scanTimer.current); };
  }, [scanPreview]);

  const filesByFolder = useMemo(() => {
    const groups: Record<string, ProjectFile[]> = {};
    for (const f of ANDROID_FILES) {
      const folder = f.path.split("/").slice(0, -1).join("/") || "root";
      if (!groups[folder]) groups[folder] = [];
      groups[folder].push(f);
    }
    return groups;
  }, []);

  const downloadZip = async () => {
    const zip = new JSZip();
    for (const f of ANDROID_FILES) {
      zip.file(f.path, f.content);
    }
    for (const f of SUPPORT_FILES) {
      zip.file(f.path, f.content);
    }
    const blob = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "panelfinder-ir-android.zip";
    a.click();
    URL.revokeObjectURL(url);
  };

  const copyFile = async () => {
    await navigator.clipboard.writeText(activeFile.content);
    setCopyMsg("Copied!");
    setTimeout(() => setCopyMsg(""), 1400);
  };

  const copyAll = async () => {
    const all = ANDROID_FILES.map(f => `// ===== ${f.path} =====\n\n${f.content}`).join("\n\n\n");
    await navigator.clipboard.writeText(all);
    setCopyMsg("All project files copied!");
    setTimeout(() => setCopyMsg(""), 1900);
  };

  // NEC waveform SVG (draws the current address)
  const necBits = useMemo(() => {
    const address = scanPreview ? scanAddr : 0x00;
    const command = 0x45;
    const bytes = [
      address & 0xFF,
      (~address) & 0xFF,
      command & 0xFF,
      (~command) & 0xFF,
    ];
    const bits: number[] = [];
    for (const b of bytes) {
      for (let i = 0; i < 8; i++) bits.push((b >> i) & 1);
    }
    return bits;
  }, [scanAddr, scanPreview]);

  return (
    <div className="min-h-screen bg-[#101016] text-zinc-200 antialiased">
      <div className="border-b border-zinc-800/90 bg-[#12121a]/80 backdrop-blur">
        <div className="max-w-7xl mx-auto px-6 lg:px-10 h-[72px] flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="h-10 w-10 rounded-[13px] bg-[#e53935] flex items-center justify-center shadow-[0_10px_30px_rgba(229,57,53,0.19)]">
              <svg width="21" height="21" viewBox="0 0 24 24" fill="none"><path d="M12 3v10M7.5 13.5 12 18l4.5-4.5M5 21h14" stroke="white" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"/></svg>
            </div>
            <div>
              <div className="text-[15.5px] font-[600] tracking-tight text-zinc-100">PanelFinder IR</div>
              <div className="text-[12px] text-zinc-500">Chinese MP3 / BT Audio Panel • NEC Brute-Force</div>
            </div>
            <div className="hidden lg:flex items-center gap-2 ml-7 text-[11.8px] text-zinc-500">
              <span className="px-2.5 py-1 rounded-full bg-zinc-800/90 border border-zinc-700/70">Kotlin</span>
              <span className="px-2.5 py-1 rounded-full bg-zinc-800/90 border border-zinc-700/70">API 21 – 34</span>
              <span className="px-2.5 py-1 rounded-full bg-zinc-800/90 border border-zinc-700/70">ConsumerIrManager</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={copyAll}
              className="text-[13px] font-medium text-zinc-300 hover:text-white px-3.5 py-2 rounded-full border border-zinc-700/90 hover:border-zinc-600 transition"
            >
              Copy all
            </button>
            <button
              onClick={downloadZip}
              className="text-[13.5px] font-[600] bg-[#e53935] text-white px-4.5 py-2.5 rounded-full shadow-[0_10px_30px_rgba(229,57,53,0.22)] hover:bg-[#d62f2b] transition"
            >
              Download Android Studio Project
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-10 py-10 grid grid-cols-1 xl:grid-cols-[430px_1fr] gap-9">
        {/* Left column */}
        <div className="space-y-7">
          <div className="rounded-[28px] bg-[#161621] border border-zinc-800 shadow-lg">
            <div className="px-7 pt-7 pb-5">
              <div className="text-[11px] tracking-widest text-[#ff8760] font-[650]">PANEL FINDER IR</div>
              <div className="text-[12.4px] text-zinc-500 mt-1">MP3 / Bluetooth Panel</div>

              <div className="text-center mt-8">
                <div className="text-[18.5px] text-white font-medium">Ready to Scan</div>
                <div className="mt-3 inline-flex items-center px-4 py-[7px] bg-[#232331] rounded-full border border-zinc-700/70 text-[12.6px] text-[#ffd7c6] font-mono tracking-wider">
                  {scanPreview ? `0x${scanAddr.toString(16).padStart(2, "0").toUpperCase()}  |  CMD 0x45` : "IDLE"}
                </div>
              </div>

              <div className="flex justify-center mt-8">
                <button
                  onClick={() => setScanPreview(v => !v)}
                  className={`w-[198px] h-[198px] rounded-full relative transition-all duration-200 ${
                    scanPreview ? "scale-[0.985]" : ""
                  }`}
                  style={{ 
                    background: scanPreview
                      ? "radial-gradient(110px at 49% 46%, #39a53d 0%, #2e7d32 65%)"
                      : "radial-gradient(110px at 49% 46%, #f44a44 0%, #d92b26 65%)"
                  }}
                >
                  <span className={`absolute inset-[15px] rounded-full ${scanPreview ? "border border-[#66bb6a]/70" : "border border-[#ff7466]/70"}`}></span>
                  <span className="relative text-white font-[800] text-[20px] tracking-wider leading-tight block">
                    {scanPreview ? (
                      <>STOP<br/>SCAN</>
                    ) : (
                      <>START<br/>SCAN</>
                    )}
                  </span>
                </button>
              </div>

              <div className="text-center text-[11.9px] text-zinc-500 mt-4">
                Carrier: 38 kHz • NEC
              </div>

              <div className="mt-9 pb-2">
                <div className="text-[11px] text-[#ff8360] tracking-widest font-[650]">HOW TO USE</div>
                <p className="text-[13.8px] text-zinc-400 mt-3 leading-relaxed">
                  1. Point the top IR LED of your phone directly at the MP3/Bluetooth panel, 1–3 m.<br/><br/>
                  2. Tap START SCAN. The app transmits NEC Power (0x45) across all 256 device addresses, one every 1.2s.<br/><br/>
                  3. Watch the panel. When it responds — powers on/off, flashes, or beeps — tap STOP SCAN immediately.<br/><br/>
                  4. Your panel’s IR address is shown. Save it for remotes / HA.
                </p>
                <div className="font-mono text-[11.3px] text-zinc-500 mt-5">
                  Protocol: NEC 38 kHz • Cmd 0x45<br />
                  Address sweep: 0x00 → 0xFF • Interval: 1200 ms
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-[24px] bg-[#171721] border border-zinc-800 px-6 pt-5 pb-5">
            <div className="text-[12.8px] font-[600] text-zinc-300">NEC Signal • Live</div>
            <div className="text-[11.6px] text-zinc-500 mt-1">Address 0x{scanAddr.toString(16).toUpperCase().padStart(2,"0")} • CMD 0x45 • 38 kHz</div>
            {/* Simple NEC waveform */}
            <div className="mt-4 rounded-xl bg-[#12121a] border border-zinc-800 px-4 py-3 overflow-x-auto">
              <svg viewBox="0 0 760 60" width="760" height="60" className="block">
                {/* leader */}
                <line x1="8" y1="26" x2="70" y2="26" stroke="#ff7a54" strokeWidth="2.7"/>
                <line x1="70" y1="26" x2="102" y2="26" stroke="#424255" strokeWidth="2.7"/>
                {necBits.slice(0,32).map((bit, i) => {
                  const x = 108 + i * 19;
                  const spaceLen = bit ? 13 : 4;
                  return (
                    <g key={i}>
                      {/* burst */}
                      <line x1={x} y1={26} x2={x+3.5} y2={26} stroke="#ff7a54" strokeWidth="2.4"/>
                      {/* space */}
                      <line x1={x+3.5} y1={26} x2={x+3.5+spaceLen} y2={26} stroke="#424255" strokeWidth="2.4"/>
                    </g>
                  )
                })}
                <text x="8" y="51" fill="#6e6e84" fontSize="9" fontFamily="monospace">LEAD 9.0 / 4.5 ms</text>
                <text x="108" y="51" fill="#6e6e84" fontSize="9" fontFamily="monospace">32 bits : ADDR + ~ADDR + CMD + ~CMD</text>
              </svg>
            </div>
            <div className="text-[11.3px] text-zinc-500 mt-3 font-mono">
              Logic 1: 560µs + 1690µs &nbsp; • &nbsp; Logic 0: 560µs + 560µs
            </div>
          </div>

          <div className="rounded-[24px] bg-[#191925] border border-zinc-800 px-6 py-5 text-[13.1px] text-zinc-400 leading-relaxed">
            <div className="text-zinc-200 font-[600] mb-2">Build an APK on GitHub</div>
            <ol className="list-decimal ml-4 space-y-1.5 text-zinc-400">
              <li>Download the ZIP → unzip</li>
              <li>Push to a new GitHub repo</li>
              <li>Actions tab → "Android CI" runs automatically</li>
              <li>Download <code className="text-zinc-200">app-debug.apk</code> from the run artifacts</li>
            </ol>
            <p className="mt-3 text-zinc-500 text-[12.5px]">Works on Xiaomi / Redmi / Poco / Huawei phones with a built-in IR blaster. Min SDK 21.</p>
          </div>
        </div>

        {/* Right: code browser */}
        <div className="rounded-[28px] bg-[#14141d] border border-zinc-800 shadow-xl min-h-[890px] flex flex-col overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3.5 border-b border-zinc-800">
            <div className="text-[12.6px] text-zinc-400 font-mono">
              {activeFile.path}
            </div>
            <div className="flex items-center gap-3">
              <span className="text-[11.8px] text-emerald-400/90 min-w-[84px] text-right">{copyMsg}</span>
              <button
                onClick={copyFile}
                className="text-[12.5px] px-3 py-1.5 rounded-full bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-zinc-300"
              >
                Copy file
              </button>
            </div>
          </div>

          <div className="flex flex-1 min-h-0">
            <aside className="w-[320px] border-r border-zinc-800 bg-[#12121a] overflow-y-auto">
              <div className="px-4 pt-4 pb-5 text-[11px] text-zinc-500 tracking-wide">PANEL_FINDER_IR/</div>
              {Object.entries(filesByFolder).map(([folder, files]) => (
                <div key={folder} className="px-4 pb-4">
                  <div className="text-[11.4px] text-zinc-500 font-medium mb-1.5">{folder}/</div>
                  <div className="space-y-1">
                    {files.map(f => {
                      const fileName = f.path.split("/").pop()!;
                      const active = f.path === activeFile.path;
                      return (
                        <button
                          key={f.path}
                          onClick={() => setActiveFile(f)}
                          className={`w-full text-left text-[13px] px-3 py-[7px] rounded-lg font-mono transition ${
                            active
                              ? "bg-[#221c24] text-[#ffbba3] border border-[#ff79574d]"
                              : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/70"
                          }`}
                        >
                          {fileName}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
              <div className="px-4 pb-8 text-[11.7px] text-zinc-500">
                + gradlew, gradle-wrapper, mipmap icons … included in ZIP
              </div>
            </aside>

            <main className="flex-1 min-w-0 bg-[#111119]">
              <pre className="text-[12.7px] leading-[1.62] px-6 py-6 overflow-auto h-full text-zinc-300 font-[450] font-mono" style={{fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace'}}>
{activeFile.content}
              </pre>
            </main>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-10 pb-16">
        <div className="rounded-[22px] bg-[#151520] border border-zinc-800 px-7 py-6 grid grid-cols-1 md:grid-cols-3 gap-7 text-[13.1px] text-zinc-400">
          <div>
            <div className="text-zinc-200 font-semibold mb-1">MainActivity.kt</div>
            ConsumerIrManager init with hasIrEmitter() guard, Handler / Looper scan loop at 1200 ms, toggle kill-switch with removeCallbacksAndMessages(null), NEC pattern generator as requested.
          </div>
          <div>
            <div className="text-zinc-200 font-semibold mb-1">generateNecPattern(address, command)</div>
            38 kHz. Leader 9000 / 4500 µs. 32-bit frame ADDR + ~ADDR + CMD + ~CMD. Bit 1 = 560 / 1690 µs. Bit 0 = 560 / 560 µs. Stop 560 µs.
          </div>
          <div>
            <div className="text-zinc-200 font-semibold mb-1">activity_main.xml</div>
            Dark ConstraintLayout. tv_status (white, 18sp, "Ready to Scan"). btn_brute_force circular, #E53935, "START\nSCAN". Full usage instructions.
          </div>
        </div>
        <p className="text-center text-[11.9px] text-zinc-600 mt-6">PanelFinder IR • Not affiliated with any MP3 panel manufacturer. For legitimate device recovery / repair use.</p>
      </div>
    </div>
  );
}

export default App;
// Zod Schema
export const Schema = {
    "commentary": "This is a complete Android Studio project generator for an IR blaster cracker targeting generic Chinese MP3/Bluetooth audio panels.  It includes a fully functional Kotlin app using ConsumerIrManager with NEC protocol encoding (38kHz, 0x45 power command, address brute-force 0x00-0xFF), a dark-themed UI with a circular scan button, and a GitHub Actions workflow for building APKs.  The web app provides a code explorer with syntax highlighting and one-click ZIP download for the entire Android project.",
    "template": "nextjs-developer",
    "title": "PanelFinder IR",
    "description": "A complete Android (Kotlin) IR blaster project generator for Chinese MP3/Bluetooth audio panels.  It brute-forces NEC IR addresses with a native ConsumerIrManager implementation and includes a ready-to-build Android Studio project with GitHub Actions APK building.",
    "additional_dependencies": [
        "jszip",
        "file-saver"
    ],
    "has_additional_dependencies": true,
    "install_dependencies_command": "npm install jszip file-saver",
    "port": 5173,
    "file_path": "src/App.tsx",
    "code": "<see code above>"
}